function passe_bande()
M=input('nb echantion svp impaire ');
Fcnd1=input('Fcnd(0<=Fcnd1<=0.5)');
Fcnd2=input('Fcnd(0<=Fcnd2<=0.5)');
hpnd=[];
for m=0:M-1
    num=sin(2*pi*Fcnd2*(m-(M-1)/2))-sin(2*pi*(Fcnd1*(m-(M-1)/2)));
    den=pi*(m-(M-1)/2);
if(den~=0)
    hpnd=[hpnd num/den];
else
    hpnd=[hpnd 2*Fcnd2-2*Fcnd1];
end
end
%figure;plot(0:M-1,hpb,'r')

hphw=hpnd.*hamming(M)';

figure;plot(0:M-1,hpnd,'r',0:M-1,hphw,'k');
Fe=1;
N=1024;
[Hpnd,F]=freqz(hpnd,1,N,Fe);
[Hphw,F]=freqz(hphw,1,N,Fe);
figure;plot([0 Fcnd1 Fcnd1 Fcnd2 Fcnd2 Fe/2],[0 0 1 1 0 0], F,abs(Hpnd),F,abs(Hphw));
legend('Gab','hssfen','havecfen')
end