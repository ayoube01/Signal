function passe_haut()
clc;clear;close all;
M=input('nb echantion svp impaire ');
Fcph=input('Fcph(0<=Fcph<=0.5)');
hph=[];
for m=0:M-1
    num=sin(pi*(m-(M-1)/2))-sin(2*pi*Fcph*(m-(M-1)/2));
    den=pi*(m-(M-1)/2);
if(den~=0)
    hph=[hph num/den];
else
    hph=[hph 1-2*Fcph];
end
end
%figure;plot(0:M-1,hpb,'r')

hphw=hph.*hamming(M)';

figure;plot(0:M-1,hph,'r',0:M-1,hphw,'k');
Fe=1;
N=1024;
[Hph,F]=freqz(hph,1,N,Fe);
[Hphw,F]=freqz(hphw,1,N,Fe);
figure;plot([0 Fcph Fcph Fe/2],[0 0 1 1], F,abs(Hph),F,abs(Hphw));
legend('Gab','hssfen','havecfen')
end