
choix = menu('filtres', 'passe_bas','passe_haut','passe_bande','coupe_bande')
if( choix==1)
    passe_bas()
end
if( choix==2)
  passe_haut()
end
if( choix==3)
    passe_bande()
end
if( choix==4)
    coupe_bande()
end
