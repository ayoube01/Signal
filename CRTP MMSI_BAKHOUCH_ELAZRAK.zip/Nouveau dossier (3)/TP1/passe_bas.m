function passe_bas()
clc;clear;close all;
M=input('nb echantion svp impaire ');
Fcpb=input('Fcpb(0<=Fcpb<=0.5)');
hpb=[];
for m=0:M-1
    num=sin(2*pi*Fcpb*(m-(M-1)/2));
    den=pi*(m-(M-1)/2);
if(den~=0)
    hpb=[hpb num/den];
else
    hpb=[hpb 2*Fcpb];
end
end
%figure;plot(0:M-1,hpb,'r')

hpbw=hpb.*hamming(M)';

figure;plot(0:M-1,hpb,'r',0:M-1,hpbw,'k');
Fe=1;
N=1024;
[Hpb,F]=freqz(hpb,1,N,Fe);
[Hpbw,F]=freqz(hpbw,1,N,Fe);
figure;plot([0 Fcpb Fcpb Fe/2],[1 1 0 0], F,abs(Hpb),F,abs(Hpbw));
legend('Gab','hssfen','havecfen')
end