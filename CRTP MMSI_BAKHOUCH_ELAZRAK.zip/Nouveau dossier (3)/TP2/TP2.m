clear all;
close all;
clc;
%MODELE ANALOGIQUE
tau=10^-3;
N=1024;
num_a=[0 1];
den_a=[tau 1];
d1=0.1;
d2=6;
w_a=logspace(d1,d2,N);
f_a=w_a./(2*pi);
H_a=freqs(num_a,den_a,w_a);
phase_a=angle(H_a)*180/pi; %en degr�;
figure;
subplot(211);semilogx(f_a,20*log(abs(H_a)));title('H(p):model analogique'),grid
subplot(212);semilogx(f_a,phase_a);grid
%INVARIANCE IMPULSIONNELLE
Te=tau/4;
Fe=1/Te;
num_imp=[1-exp(-Te/tau) 0];
den_imp=[1 -exp(-Te/tau)];
[H_imp,F_imp]=freqz(num_imp,den_imp,N,Fe);
phase_imp=angle(H_imp)*180/pi;
%Methode d'Euler
num_eu=[1 0];
den_eu=[1+tau/Te -tau/Te];
[H_eu,F_eu]=freqz(num_eu,den_eu,N,Fe);
Phase_eu = angle(H_eu)*180/pi;
%Methode des rectangles
num_rect = [0 Te];
den_rect = [tau Te-tau];
[H_rect,F_rect] = freqz(num_rect,den_rect,N,Fe);
Phase_rect = angle (H_rect)*180/pi;
%Methode des trap�zes
num_trap=[Te Te];
den_trap=[Te+2*tau Te-2*tau];
[H_trap,F_trap]=freqz(num_trap,den_trap,N,Fe);
Phase_trap = angle(H_trap)*180/pi;
%Superposition des courbes
figure;
semilogx(f_a,abs(H_a),F_imp,abs(H_imp),F_eu,abs(H_eu),F_rect,abs(H_rect),F_trap,abs(H_trap));grid;legend('ANALOGIQUE','INV IMPULS','EULER','RECTANGLE','TRAPEZE')
figure;
semilogx(f_a,phase_a,F_imp,phase_imp,F_eu,Phase_eu,F_rect,Phase_rect,F_trap,Phase_trap);grid
% module et sa phase 
