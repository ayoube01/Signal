%MODEL NUMERIQUE
clc;clear;close all;
tau=1e-3;
d1=0.1;
d2=6;
N=1024;
num_a=[0 1];
den_a=[tau 1];
W_a=logspace(d1,d2,N);
f_a=W_a/(2*pi);
H_a=freqs(num_a,den_a,W_a)
phase_a=angle(H_a)*180/pi;
figure;
subplot(211);semilogx(f_a,20*log10(abs(H_a)));title('H(p):model');grid
subplot(212);semilogx(f_a,phase_a);grid
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
te=tau/4;
fe=1/te;
num_imp=[ 1-exp(-te/tau) 0];
den_imp=[1 -exp(-te/tau)];
[H_imp,F_imp]=freqz(num_imp,den_imp,N,fe);
phaseimp=angle(H_imp)*180/pi;
figure;
semilogx(f_a,abs(H_a),F_imp,abs(H_imp));grid;
figure;
semilogx(f_a,phase_a,F_imp,phaseimp);grid;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
num_eu=[te/(te+tau) 0];
den_eu=[1 -tau/(te+tau)];
[H_eu,F_eu]=freqz(num_eu,den_eu,N,fe);
phaseeu=angle(H_eu)*180/pi;
figure;
semilogx(f_a,abs(H_a),F_eu,abs(H_eu));grid;
figure;
semilogx(f_a,phase_a,F_eu,phaseeu);grid;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%rectangle
num_r=[0 te/tau];
den_r=[1 (te-tau)/tau];
[H_r,F_r]=freqz(num_r,den_r,N,fe);
phaser=angle(H_r)*180/pi;
figure;
semilogx(f_a,abs(H_a),F_r,abs(H_r));grid;
figure;
semilogx(f_a,phase_a,F_r,phaser);grid;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%trap�ze

